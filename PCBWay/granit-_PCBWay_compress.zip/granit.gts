G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.0*
G04 #@! TF.CreationDate,2026-04-09T08:42:51+00:00*
G04 #@! TF.ProjectId,granit,6772616e-6974-42e6-9b69-6361645f7063,0.1*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.0) date 2026-04-09 08:42:51*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
